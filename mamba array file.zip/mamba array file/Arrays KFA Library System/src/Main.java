import kfa.model.*;
import kfa.service.*;

public class Main {
    public static void main(String[] args) {

        System.out.println("===== SECTION A =====");
        // A1: String cleaning test
        String messy = "   aLIce   iN  wONdeRlaNd   ";
        System.out.println("Original : '" + messy + "'");
        System.out.println("Cleaned  : '" + LibrarySystem.sanitizeTitle(messy) + "'");

        // A2: Receipt & String comparison test
        Book testBook = new Book("To Kill a Mockingbird", "9780061120084", 890.0);
        System.out.println("\n" + LibrarySystem.generateReceiptText("Pooja Thapa", testBook));

        String str1 = "9780061120084";
        String str2 = new String("9780061120084");

        System.out.println("Testing String equality:");
        System.out.println("str1 == str2      : " + (str1 == str2));
        System.out.println("str1.equals(str2) : " + str1.equals(str2));


        System.out.println("\n===== SECTION B =====");
        // B1: 5x10 Grid Test
        String[][] shelves = new String[5][10];
        for (int r = 0; r < 5; r++) {
            for (int c = 0; c < 10; c++) {
                shelves[r][c] = "";
            }
        }

        LibrarySystem.placeOnShelf(shelves, "9780061120084");
        LibrarySystem.placeOnShelf(shelves, "9780316769488");
        LibrarySystem.printShelves(shelves);

        // B2: Array reverse and highest price scan
        Book[] myBooks = new Book[] {
                new Book("Operating Systems", "9780133591620", 1100.0),
                new Book("Computer Networks", "9780132126953", 1650.0),
                new Book("Database Concepts", "9780073523323", 1420.0),
                new Book("Discrete Math", "9780073383095", 980.0),
                new Book("Artificial Intelligence", "9780134610993", 2100.0)
        };

        System.out.println("\nMost expensive book: " + LibrarySystem.findMostExpensive(myBooks));

        System.out.println("\nBefore reversal:");
        for (Book b : myBooks) {
            System.out.println(" -> " + b.getTitle());
        }

        LibrarySystem.reverseInPlace(myBooks);

        System.out.println("After reversal:");
        for (Book b : myBooks) {
            System.out.println(" -> " + b.getTitle());
        }


        System.out.println("\n===== SECTION C =====");
        LibrarySystem lib = new LibrarySystem();

        Book b1 = new Book("Python Crash Course", "9781593279288", 950.0);
        Book b2 = new Book("Design Patterns", "9780201633610", 1800.0);
        Magazine m1 = new Magazine("Time Magazine", "9787777777777", 320.0, 88);
        DVD d1 = new DVD("Oppenheimer", "9786666666666", 650.0, 180);

        lib.addItem(b1);
        lib.addItem(b2);
        lib.addItem(m1);
        lib.addItem(d1);

        System.out.println("\n--- Sorted by Price ---");
        lib.sortByPrice();
        lib.displayCatalogue();

        System.out.println("\n--- Sorted by Title ---");
        lib.sortByTitle();
        lib.displayCatalogue();

        System.out.println("\nRemoving 'Design Patterns'...");
        lib.removeItem("9780201633610");
        lib.displayCatalogue();

        System.out.println("\nTesting Undo...");
        lib.undoRemove();
        lib.displayCatalogue();


        System.out.println("\n===== SECTION D =====");
        // D1: Double-borrow check
        String isbnCheck = "9781593279288";
        System.out.println("Borrow 1st time : " + lib.borrow(isbnCheck));
        System.out.println("Borrow 2nd time : " + lib.borrow(isbnCheck));
        System.out.println("Return book     : " + lib.returnBook(isbnCheck));
        System.out.println("Borrow again    : " + lib.borrow(isbnCheck));

        // D2: HashMap lookup
        System.out.println("\nMap lookup for ISBN 9781593279288:");
        System.out.println(lib.findByIsbn("9781593279288"));

        // D3: Popular book count report
        String[] logs = {
                "Oppenheimer", "Python Crash Course", "Oppenheimer",
                "Design Patterns", "Oppenheimer", "Python Crash Course"
        };
        System.out.println();
        LibrarySystem.printMostBorrowedReport(logs);
    }
}