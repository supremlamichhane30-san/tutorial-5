package kfa.exception;

public class ItemOverdueException extends Exception {
    private int daysLate;

    public ItemOverdueException(int daysLate) {
        super("Item is overdue by " + daysLate + " days!");
        this.daysLate = daysLate;
    }

    public int getDaysLate() {
        return daysLate;
    }
}