package kfa.model;

public class Book extends LibraryItem implements Renewable {
    private static int totalBooks = 0;

    public Book(String title, String isbn, double price) {
        super(title, isbn, price);
        totalBooks++;
    }

    public static int getTotalBooks() {
        return totalBooks;
    }

    @Override
    public int getLendingPeriodDays() {
        return 14; // books are lent for 2 weeks
    }

    @Override
    public void renew(int extraDays) {
        System.out.println("Renewed book " + getTitle() + " for " + extraDays + " extra days.");
    }

    @Override
    public String toString() {
        return "Book: " + getTitle() + " | ISBN: " + getIsbn() + " | Price: Rs " + getPrice();
    }
}